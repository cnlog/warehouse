#include "wninjaEx.h"
#include "../lua_gears.h"

using namespace std;

static int g_nLoadSuccess=0;	//�ֵ��Ƿ���سɹ�

WordNinga::WordNinga():m_wordMaxLen(0){}
WordNinga::~WordNinga(){}

int WordNinga::do_init(const std::string ninja_words){
	int b=0;
	try
	{
		if(g_ninga.init(ninja_words)){
			g_nLoadSuccess=1;
			b=1;
		}
	}
	catch(...)
	{
		g_nLoadSuccess=0;
	}
	return b;
}

inline bool WordNinga::isDigit(const std::string& str)
{
    std::stringstream s;
    s << str;
    double d = 0;
    char c;
    return (s >> d) ? !(s >> c): false;
}

int WordNinga::init(const std::string dictPath)
{
    m_dict.clear();
    //reading dict file
    ifstream infile(dictPath);
    if(!infile.is_open())
    {
		l_info("dict file not exist"); 
        //assert(false);
		return 0;
    }
    string word;
    vector<string> words;
    words.reserve(20000);
    while (!infile.eof())
    {
        getline(infile,word);
        if(!word.size()) 
			continue;
        words.push_back(word);
    }
    int dictSize = words.size();
	
	l_info("dictsize:"<<dictSize); 
	
    for(int i = 0; i < words.size();i++)
    {
        m_dict[words[i]] = log((i + 1) * log(dictSize));
        m_wordMaxLen = (std::max)( m_wordMaxLen,(int)(words[i].length()) );
    }
    return 1;
}

int WordNinga::split(const std::string inputText, std::vector<std::string>& result)
{
    result.clear();
    if(inputText.empty())
		return 0;
    string lowerStr = inputText;
    std::transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), (int (*)(int))tolower);
    
    const int len = lowerStr.size();

    vector<std::pair<float, int>> cost;
    cost.reserve(len + 1);///!!!!
    cost.push_back(make_pair(0, -1));
    string subStr = "";
    float curCost = 0.0;
    for(int i = 1; i < len + 1; i++)
    {
        float minCost = cost[i - 1].first + 9e9;
        int minCostIndex = i - 1;

        for(int j = i - m_wordMaxLen > 0 ? i - m_wordMaxLen : 0; j < i; j++)
        {
            subStr = lowerStr.substr(j, i - j);
            if(m_dict.find(subStr) == m_dict.end())
				continue;

            curCost = cost[j].first + m_dict.at(subStr);
            if(minCost > curCost) {
                minCost = curCost;
                minCostIndex = j;
            }
        }
        cost.push_back(std::make_pair(minCost, minCostIndex));
    }

    int n = len;
    int preIndex;
    while (n > 0)
    {
        preIndex = cost[n].second;
        string insertStr = inputText.substr(preIndex, n - preIndex);
        if(!result.empty() && isDigit(insertStr + result[0])) {
            result[0] = insertStr + result[0];
        }
        else {
            result.insert(result.begin(), insertStr);
        }
        n = preIndex;
    }
    return 1;
}


int l_word_split(lua_State *L){
	 if(!g_nLoadSuccess)						   //�ֵ��Ƿ���سɹ�
		 return luaL_error(L, "lost wordninja_words.txt");
		 
	 int nFlag=luaL_checkinteger(L,1);			   //�������黹���ַ���.0:�ַ���;1:����
	 string inputText = luaL_checkstring(L, 2);    //��Ҫ�ָ���ַ���,-1��Զ��ʾջ��,1��Զ��ʾջ��
	 
	 if(0!=nFlag && 1!=nFlag)
		 return luaL_error(L, "need string or array?");
	 
	 vector<string> result;
	 if(!g_ninga.split(inputText, result))
		return luaL_error(L, "split failed");
	
	 if(1==nFlag) {
		 lua_newtable(L);  			 //���ر�,example{"hi", "", "there"}
		 int i = 1;
		 for(auto str : result) {
			lua_pushstring(L, str.c_str());
			lua_rawseti(L, -2, i++);
		 }
		 l_info(i);
	 }else{
		 string retStr;
		 for(auto str : result) {
			retStr+=str;
			retStr+=" ";
		 }
		 lua_pushstring(L, retStr.c_str());
		 
		 //LOG(INFO) << "---------l_word_split---------- : " << retStr;
	 }
     return 1;
}

int l_debug(lua_State *L){
	lua_Debug info;
	int level = 0;
	while (lua_getstack(L, level, &info)) {
		lua_getinfo(L, "nSI", &info);
		fprintf(stderr, "  [%d] %s:%d -- %s [%s]\n",level,info.short_src, 
		info.currentline,
        (info.name ? info.name : "<unknown>"), info.what);
		++level;
	}
	return 0;
}

//---------------------------------------main----------------------------------

//cl wordninjaEx.cpp /nologo /LD /MT /O2 /Oy- /EHsc /I ./include /link ./lua54.lib  /out:wordninjaEx.dll

//wordninja.exe -n "wethepeopleoftheunitedstatesinordertofor"

/*
void testPrintStackFunction() {
    lua_State* lua = luaL_newstate();

    int stackSize = lua_gettop(lua);    // empty, so stackSize == 0;
    assert(stackSize == 0);
    
 
    lua_pushnil(lua);                   ++stackSize; // 1
    lua_pushnumber(lua, 1.2);           ++stackSize; // 2
    lua_pushstring(lua, "hello world"); ++stackSize; // 3
    lua_pushboolean(lua, 1);            ++stackSize; // 4
    lua_pushinteger(lua, 100);          ++stackSize; // 5

    printLuaStack(lua);         // ��ӡջ

    assert( (stackSize == 5) && (stackSize == lua_gettop(lua)) );

    lua_close(lua);
}
*/



/*
int main(int argc,char *argv[],char *envp[]){
	
	//cout<<argc<<" | "<<argv[1]<<"\r\n"<<endl;
	if(argc!=3) 
		return 0;
	if(strlen(argv[1])>2 || strcmp(argv[1],"-n"))
		return 0;
	
	//FILE *f=fopen("G:\\ime\\test.txt","w+");
	//fprintf(f,argv[2]);
	//fclose(f);

	WordNinga pWordNinga;
    pWordNinga.init("wordninja_words.txt");

#ifdef _DEBUG	
    string inputText = "wethepeopleoftheunitedstatesinordertoformamoreperfectunionestablishjusticeinsuredomestictranquilityprovideforthecommondefencepromotethegeneralwelfareandsecuretheblessingsoflibertytoourselvesandourposteritydoordainandestablishthisconstitutionfortheunitedstatesofamerica";
	cout<<inputText<<endl;
    //string inputText = "readinginbed";
    cout << inputText<<endl;
#else
	string inputText=argv[2];
#endif	
    vector<string> result;

    pWordNinga.split(inputText, result);

#ifdef _DEBUG	
    cout<<"result:"<<endl;
#endif		
    for(auto str : result)
    {
        cout<< str<<"   ";
    }
    cout<<endl;

    return 0;
}
*/