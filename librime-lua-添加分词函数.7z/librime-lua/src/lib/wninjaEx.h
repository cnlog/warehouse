//rime.dll���ӷִʺ���
//�ִ���ȡ�� https://github.com/jiawenhao2015/wordninja ,��лjiawenhao2015����

#ifndef SRC_WORDNINJA_H
#define SRC_WORDNINJA_H

#include <map>
#include <vector>

#include <string>
#include <cassert>
#include <algorithm>

#include <iostream>
#include <sstream>
#include <fstream>
#include <math.h>

#include "lua.h"

//#define l_info(info)  {  cout<<info<<"\r\n"<<endl; }
#define l_info(info) {}

#define WORDNINGA_WORDS "wordninja_words.txt"

extern "C"{
	
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <luaconf.h>	

//typedef int (*lua_CFunction) (lua_State *L);

extern  int  l_word_split(lua_State *L);  //����: int,string
extern  int  l_debug(lua_State *L);

extern  const char *lua_pushstring(lua_State *L, const char *s);
extern  void  lua_rawseti(lua_State *L, int idx, LUA_INTEGER n);

}; //extern "C"

//WordNinga class

class WordNinga
{
public:
    WordNinga();
    ~WordNinga();
	int do_init(const std::string ninja_words);  //�����ֵ�
    int init(const std::string dictPath);
    int split(const std::string inputText, std::vector<std::string>& result);
private:
inline  bool isDigit(const std::string& str);
private:
    std::map<std::string, float> m_dict;
    int m_wordMaxLen;
};

static WordNinga g_ninga;

#endif